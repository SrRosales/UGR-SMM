/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package p3_escritoriosmm;

import javax.swing.JInternalFrame;

/**
 *
 * @author Alejandro
 */
public class VentanaInterna extends JInternalFrame{
    
    public VentanaInterna(){
        setClosable(true); // Permite cerrar la ventana interna
        setIconifiable(true); // Permite minimizar la ventana interna
        setMaximizable(true); // Permite maximizar la ventana interna
        setResizable(true); // Permite redimensionar la ventana interna
    }
}
